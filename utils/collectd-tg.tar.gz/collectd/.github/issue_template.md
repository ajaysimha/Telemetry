*   Version of collectd:
*   Operating system / distribution:

## Expected behavior

(Description of the behavior / output that you expected)

## Actual behavior

(Description of the behavior / output that you observed)

## Steps to reproduce

*   step 1
*   step 2
*   step 3
